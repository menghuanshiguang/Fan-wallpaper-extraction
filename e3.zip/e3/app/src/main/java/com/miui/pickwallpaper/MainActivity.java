package com.miui.pickwallpaper;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.graphics.drawable.*;
import android.graphics.*;
import java.text.*;
import java.util.*;
import java.io.*;
import android.view.*;
import android.Manifest;
import android.support.v4.app.ActivityCompat;
import android.content.pm.PackageManager;
import android.content.Context;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import android.content.DialogInterface;

/**
 * 提取手机壁纸
 * Date 2021年10月23日
 * Author Unbeaten East
 */

public class MainActivity extends Activity {

	private final String ERROR = "发生错误：";
	private final String SUCCESSFUL = "保存成功！路径：%s";

	private ImageView wallpaperView;// 壁纸
	private Bitmap wallpaper;

    private ImageButton btnrotate;

    private Button btnrotate2;

    private Button btnrotate3;
    private Button btnrotate8;

    private Context context3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		//wallpaperView = new ImageView(this);
		//setContentView(wallpaperView);
        setContentView(R.layout.e);
        btnrotate=(ImageButton)findViewById(R.id.eImageButton1);
        btnrotate2=(Button)findViewById(R.id.eButton1);
        ContextHolder.initial(this);
        context3=ContextHolder.getContext();
        btnrotate2.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    
                        pickWallpaper2();
                    
                }
            });
        btnrotate3=(Button)findViewById(R.id.eButton2);
        btnrotate3.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view2) {
                    
                    try {
                        pickWallpaper(0);
                    } catch (FileNotFoundException e) {}

                }
            });
        btnrotate8=(Button)findViewById(R.id.eButton3);
        btnrotate8.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view3) {
                    
                    try {
                        if(wallpaper!=null){
                            verifyStoragePermissions(getCurrentActivity());
                            new Reminder(5);
                        saveMyBitmap(wallpaper);
                        }else{
                            showToast("没选择");
                        }
                    } catch (IOException e) {}

                }
            });
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		try {
			switch (item.getItemId()) {
				case R.id.menu_lock:
					//pickWallpaper(0);
                    onClick3();
					break;
				case R.id.menu_launcher:
					pickWallpaper(1);
					break;
			}
			//wallpaperView.setImageBitmap(wallpaper);
		} catch (Exception e) {
			showToast(ERROR + e.getMessage());
		}
		return super.onOptionsItemSelected(item);
	}

	/**
	 * 针对MIUI的，代码来自QQ群
	 */
	private void pickWallpaper(int wallpaperType) throws FileNotFoundException {
		File wallpaperFile;
		if (wallpaperType == 0) {
			wallpaperFile = new File(Environment.getDataDirectory(), "system/theme/lock_wallpaper");
		} else {
			wallpaperFile = new File(Environment.getDataDirectory(), "system/theme/wallpaper");
		}
		ParcelFileDescriptor mParcelFileDescriptor = ParcelFileDescriptor.open(wallpaperFile, ParcelFileDescriptor.MODE_READ_ONLY);
		FileDescriptor fileDescriptor = mParcelFileDescriptor.getFileDescriptor();
		wallpaper = BitmapFactory.decodeFileDescriptor(fileDescriptor);//获取Bitmap类型返回值
        wallpaperView = new ImageView(this);
        //setContentView((wallpaperView));
        btnrotate.setImageBitmap(wallpaper);
	}

	private void pickWallpaper2() {
		// 获取壁纸管理器
		WallpaperManager wallpaperManager = WallpaperManager.getInstance(this);
		// 获取当前壁纸
		Drawable wallpaperDrawable = wallpaperManager.getDrawable();
		wallpaper = ((BitmapDrawable) wallpaperDrawable).getBitmap();
        btnrotate.setImageBitmap(wallpaper);
	}

	/**
	 * 保存壁纸
	 */
	private void saveMyBitmap(Bitmap bitmap) throws FileNotFoundException, IOException  {
		SimpleDateFormat formatter= new SimpleDateFormat("yyyyMMdd_HHmmss");// 自定义日期格式
		Date date = new Date(System.currentTimeMillis());// 获取日期
		File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);// 获取图片路径（/storage/emulated/0/DCIM/）
        File f = new File(path.getAbsolutePath() + File.separator + "Wallpaper_" + formatter.format(date) + ".jpeg"); // 壁纸保存路径
        FileOutputStream fOut = new FileOutputStream(f);// 创建文件输出流
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fOut);// 设置壁纸输出流对象
		fOut.flush();// 清空缓存
        fOut.close();// 释放资源
		// 保存成功，发出提示
		showToast(String.format(SUCCESSFUL, f.getAbsolutePath()));
	}

	private void showToast(CharSequence text) {
		Toast toast;
		toast = Toast.makeText(this, null, Toast.LENGTH_LONG);
		// 这里是为了避免垃圾小米在前面加个应用名
		toast.setText(text);
		toast.show();
	}
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE" };


    public static void verifyStoragePermissions(Activity activity) {

        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity,
                                                                "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE,REQUEST_EXTERNAL_STORAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static Activity getCurrentActivity () {
        try {
            Class activityThreadClass = Class.forName("android.app.ActivityThread");
            Object activityThread = activityThreadClass.getMethod("currentActivityThread").invoke(
                null);
            Field activitiesField = activityThreadClass.getDeclaredField("mActivities");
            activitiesField.setAccessible(true);
            Map activities = (Map) activitiesField.get(activityThread);
            for (Object activityRecord : activities.values()) {
                Class activityRecordClass = activityRecord.getClass();
                Field pausedField = activityRecordClass.getDeclaredField("paused");
                pausedField.setAccessible(true);
                if (!pausedField.getBoolean(activityRecord)) {
                    Field activityField = activityRecordClass.getDeclaredField("activity");
                    activityField.setAccessible(true);
                    Activity activity = (Activity) activityField.get(activityRecord);
                    return activity;
                }
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        return null;
    }
    public void onClick()
    {
        //    通过AlertDialog.Builder这个类来实例化我们的一个AlertDialog的对象
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        //    设置Title的图标
        builder.setIcon(R.drawable.ic_launcher);
        //    设置Title的内容
        builder.setTitle("弹出警告框");
        //    设置Content来显示一个信息
        builder.setMessage("确定删除吗？");
        //    设置一个PositiveButton
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    Toast.makeText(MainActivity.this, "positive: " + which, Toast.LENGTH_SHORT).show();
                }
            });
        //    设置一个NegativeButton
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    Toast.makeText(MainActivity.this, "negative: " + which, Toast.LENGTH_SHORT).show();
                }
            });
        //    设置一个NeutralButton
        builder.setNeutralButton("忽略", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    Toast.makeText(MainActivity.this, "neutral: " + which, Toast.LENGTH_SHORT).show();
                }
            });
        //    显示出该对话框
        builder.show();
    }
    public void onClick3()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setIcon(R.drawable.ic_launcher);
        builder.setTitle("请输入用户名和密码");
        //    通过LayoutInflater来加载一个xml的布局文件作为一个View对象
        View view = LayoutInflater.from(MainActivity.this).inflate(R.layout.dialog, null);
        //    设置我们自己定义的布局文件作为弹出框的Content
        builder.setView(view);

        //final EditText username = (EditText)view.findViewById(R.id.username);
        //final EditText password = (EditText)view.findViewById(R.id.password);

        builder.setPositiveButton("确定", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {
                    //String a = username.getText().toString().trim();
                    //String b = password.getText().toString().trim();
                    //    将输入的用户名和密码打印出来
                    //Toast.makeText(MainActivity.this, "用户名: " + a + ", 密码: " + b, Toast.LENGTH_SHORT).show();
                } 
            });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener()
            {
                @Override
                public void onClick(DialogInterface dialog, int which)
                {

                }
            });
        builder.show();
    }
    

}
